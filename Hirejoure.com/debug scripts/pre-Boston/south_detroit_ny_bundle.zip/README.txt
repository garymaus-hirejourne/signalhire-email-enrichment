
South Detroit NY Bundle
------------------------

This archive includes:
- NY_PE_Company_List.csv: The list of 12 private equity firms in NYC.
- south_detroit_full_pipeline.py: The master script for scraping, filtering, and enriching contact info.

To run:
1. Install dependencies (Playwright, pandas, requests, etc.).
2. Run the Python script on your local machine.
3. Output will be saved in CSV format, ready for Gmail merge.

Created with: ChatGPT + Playwright + Hunter.io + Custom Filters
